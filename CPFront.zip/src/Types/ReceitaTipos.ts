export interface ReceitaTipos {
  id: number;
  categoria: string;
  nome: string;
  link: string;
  ingredientes: string[];
  modoPreparo: string;
  tempo: string;
  imagem: string;
}
